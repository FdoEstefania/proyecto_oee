<?PHP
require "conexion.php";
$json=array();
//metodos que verifica si se inserta un dato o no
if(isset($_GET["user"]) && isset($_GET["pwd"])){
    $user= $_GET['user'];
    $pwd= $_GET['pwd'];

    //realizad la cunsulta de la tabla usuario a la base de datos
    $consulta="SELECT correo_usu, contrasena_usu, nom_usu, ape_usu, fk_empresa FROM usuario WHERE correo_usu = '{$user}' ";
    $result=mysqli_query($con,$consulta);
    $fila = $result->fetch_assoc();
    $pass = $fila['contrasena_usu'];

    //metodo que verifica que si la contraseña insertada es igual a la encriptada en la base de datos
    if($consulta){
        if(password_verify($pwd, $pass)){

            //funcion que guarda en una variable el resultado de la consulta
            $resultado=mysqli_query($con,$consulta);

            //metodo que guarda los resultado de la consulta en un array
            if($reg=mysqli_fetch_array($resultado)){
                $json['datos'][]=$reg;
            }
            //metodo que muestra los resultado en pantalla y el cierre de la conexion
            mysqli_close($con);
            echo json_encode($json);
        }
    }
    else{
        $results["correo_usu"]='';
        $results["contraseña_usu"]='';
        $results["nom_usu"]='';
        $results["ape_usu"]='';
        $results["fk_empresa"]='';
        $json['datos'][]=$results;
        echo json_encode($json);
    }

}
else{
    $results["user"]='';
    $results["pwd"]='';
    $results["name"]='';
    $results["ape_usu"]='';
    $results["fk_empresa"]='';
    $json['datos'][]=$results;
    echo json_encode($json);
}
?>
